include T('default/method_details/html')

def init
  sections :header, [:method_signature, T('docstring')]
end
